#import pandas as pd
import numpy as np
import collections
from collections import Counter

# please use regex to show methods of extracting specific words 
def main():
    with open(r'/Users/gbimes/Downloads/iprice/text files/all-places-strings.lc.txt')as f1:
        words1 =  [word for line in f1 for word in line.split()]

    with open(r'/Users/gbimes/Downloads/iprice/text files/all-people-strings.lc.txt')as f2:
        words2 =  [word for line in f2 for word in line.split()]

    with open(r'/Users/gbimes/Downloads/iprice/text files/all-exchanges-strings.lc.txt')as f3:
        words3 =  [word for line in f3 for word in line.split()]

    with open(r'/Users/gbimes/Downloads/iprice/text files/all-orgs-strings.lc.txt')as f4:
        words4 =  [word for line in f4 for word in line.split()]

    with open(r'/Users/gbimes/Downloads/iprice/text files/all-topics-strings.lc.txt')as f5:
        words5 =  [word for line in f5 for word in line.split()]
        print words5

    with open(r'/Users/gbimes/Downloads/iprice/text files/cat-descriptions_120396.txt')as f6:
        words6 =  [word for line in f6 for word in line.split()]

    with open(r'/Users/gbimes/Downloads/iprice/text files/feldman-cia-worldfactbook-data.txt')as f7:
        words7 =  [word for line in f7 for word in line.split()]

    with open(r'/Users/gbimes/Downloads/iprice/book/countries.txt')as f8:
        book =  [word for line in f8 for word in line.split()]


        words = words1 + words2 + words3 + words4 + words5 + words6 + words7
        
        print "The total word count is:", len(words)
        print "The total word count is:", len(book)

        c = Counter(words)
        d = Counter(book)

        texts = []
        textscountfinal= []
        booktexts = []
        booktextscount = []
        nothing = 0

        
        for word, count in c.items():
            texts.append(word)

        for word, count in d.items():
            booktexts.append(word)
            booktextscount.append(count)
        
        
        for item in texts:
            if item in booktexts:
                textscountfinal.append(booktextscount[booktexts.index(item)])
            else:
                textscountfinal.append(0)

      
        print "The total matching words", len(texts)
        print "The total matching counts:", len(textscountfinal)
        


        
main()

